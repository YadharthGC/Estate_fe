import React from "react";
import "./header.css";

export const Home = () => {
  return (
    <div id="HOME">
      <div className="homeA">
        <div>
          <div>Best Places</div>
          <div>in the Affordable Prices</div>
        </div>
      </div>
      <div className="homeB">opening hours - Mon-fri , 9.00am-9.00pm</div>
    </div>
  );
};
